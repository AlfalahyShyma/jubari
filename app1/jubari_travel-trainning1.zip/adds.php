<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adds extends Model
{

}
