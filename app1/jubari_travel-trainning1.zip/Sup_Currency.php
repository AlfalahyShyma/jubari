<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sup_Currency extends Model
{
    protected $table="sup_currency";
}
